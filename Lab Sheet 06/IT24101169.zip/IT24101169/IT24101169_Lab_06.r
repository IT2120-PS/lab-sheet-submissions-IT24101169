getwd()
setwd("C:\\Users\\User\\Desktop\\IT24101169")
getwd()
#question 1
#i) 
#Binomial Distribution

#ii) 
#at least 47 student passed
#P(X>=47) = 1-P(X<=46)
1 - pbinom(46, 50, 0.85,lower.tail = TRUE)

#question 2
#i)
# X = Number of calls received in one hour

#ii) 
#Poisson Disribution 

#iii)
#exactly 6
dpois(6,12)
